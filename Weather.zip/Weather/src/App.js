
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Stripe } from "./components/Stripe";
function App() {
  return (
    <>
    <Stripe></Stripe>
    </>
  );
}
export default App;
